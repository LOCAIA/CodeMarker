/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef CODEMARKER_PRIVATE_H
#define CODEMARKER_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.0.0.10"
#define VER_MAJOR	1
#define VER_MINOR	0
#define VER_RELEASE	0
#define VER_BUILD	10
#define COMPANY_NAME	"L�o CUTTAIA"
#define FILE_VERSION	"1.0.0.10"
#define FILE_DESCRIPTION	"Ecrivez, Editez, Executez les fichiers MarkDown avec une grande simplicit�"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	""
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"CodeMarker"
#define PRODUCT_VERSION	"1.0.0.10"

#endif /*CODEMARKER_PRIVATE_H*/

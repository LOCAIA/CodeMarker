#include <iostream>
#include <windows.h>

// Fonction pour supprimer un fichier ou un répertoire récursivement
bool deleteFileOrDirectory(const std::wstring& path) {
    DWORD attributes = GetFileAttributesW(path.c_str());
    if (attributes == INVALID_FILE_ATTRIBUTES) {
        // Impossible de récupérer les attributs, fichier ou répertoire inexistant
        return false;
    }

    if (attributes & FILE_ATTRIBUTE_DIRECTORY) {
        // C'est un répertoire, supprimer son contenu d'abord
        std::wstring wildcardPath = path + L"\\*";
        WIN32_FIND_DATAW findData;
        HANDLE hFind = FindFirstFileW(wildcardPath.c_str(), &findData);
        if (hFind != INVALID_HANDLE_VALUE) {
            do {
                if (wcscmp(findData.cFileName, L".") != 0 && wcscmp(findData.cFileName, L"..") != 0) {
                    std::wstring filePath = path + L"\\" + findData.cFileName;
                    if (!deleteFileOrDirectory(filePath)) {
                        FindClose(hFind);
                        return false;
                    }
                }
            } while (FindNextFileW(hFind, &findData));
            FindClose(hFind);
        }

        // Supprimer le répertoire une fois vide
        if (!RemoveDirectoryW(path.c_str())) {
            return false;
        }
    } else {
        // C'est un fichier, supprimer directement
        if (!DeleteFileW(path.c_str())) {
            return false;
        }
    }

    return true;
}

int main() {
    // Liste des chemins à supprimer
    std::wstring pathsToDelete[] = {
        L"build",
        L"config",
        L"dll",
        L"include",
        L"libs",
        L"scr",
        L"CodeMarker_private.h",
        L"CodeMarker_private.rc",
        L"CodeMarker_private.res",
        L"CodeMarker.exe",
        L"CodeMarker.exe.Manifest",
        L"CodeMarker.ico",
        L"Makefile.win"
    };

    // Supprimer chaque chemin dans la liste
    for (const auto& path : pathsToDelete) {
        if (!deleteFileOrDirectory(path)) {
            std::wcout << L"Erreur lors de la suppression de : " << path << std::endl;
        } else {
            std::wcout << L"Suppression réussie de : " << path << std::endl;
        }
    }

    return 0;
}
